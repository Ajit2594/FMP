function PageLoading() {
    return (
        <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" style={{
            height: '40%',
            display: 'block',
            marginLeft: 'auto',
            marginRight: 'auto',
            marginTop: '12.5%',
            width: '40%'
}}/>
     );
}

export default PageLoading;