1. extract frontend and backend folder
2. open backend in eclips
3. go com.marketplace
	/open file FarmersMarketPlaceApplication 
	/click and "Run as" after
 	"Java Application"
3. open frontend in vs code
4. open terminal
	 and "npm install --force" 
	and after "npm start"

