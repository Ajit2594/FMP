# CDAC-Project
This project was created for PG-DAC course of CDAC Institute. This is an e-commerce marketplace for farmers.

## Collaborators
[![Contributors](https://contrib.rocks/image?repo=rohitkbc/CDAC-Project)](https://github.com/rohitkbc/CDAC-Project/graphs/contributors)

## Login Page
![image](https://user-images.githubusercontent.com/100275369/194843407-a8fa0c77-b7ab-4e40-8729-8acea0b45a1f.png)

## Admin Home Page
![image](https://user-images.githubusercontent.com/100275369/194843620-2250391e-77db-41cc-b6da-b0dffcbba045.png)
![image](https://user-images.githubusercontent.com/100275369/194843513-4ea930d8-df4c-45e7-8bf8-b17b794dfc63.png)
![image](https://user-images.githubusercontent.com/100275369/194843534-ebea15fd-ba6b-4a79-9382-6793ce5af0e9.png)
![image](https://user-images.githubusercontent.com/100275369/194843551-6fa84521-a4e2-4490-bb65-5466ef87b500.png)
![image](https://user-images.githubusercontent.com/100275369/194843568-4939f175-01ee-4214-ba03-121c1eed9306.png)
![image](https://user-images.githubusercontent.com/100275369/194843582-dbefda44-748f-440e-83b9-c7ebc7a7ffa8.png)
![image](https://user-images.githubusercontent.com/100275369/194843592-03f9abc3-0a1b-4107-a347-b0f4a08b3c2a.png)

## User Home Page
![image](https://user-images.githubusercontent.com/100275369/194843719-80cbf9db-fddf-4a19-9d88-5c8b13dc0759.png)
![image](https://user-images.githubusercontent.com/100275369/194843763-35d33de2-2b1d-4cbb-94be-6f23b1d25c3f.png)
![image](https://user-images.githubusercontent.com/100275369/194843774-d400561f-2150-40df-a2d3-a654289d9a43.png)
![image](https://user-images.githubusercontent.com/100275369/194843806-d121d907-0e28-4dcd-b152-d872aa09dd0b.png)
![image](https://user-images.githubusercontent.com/100275369/194843845-068f120d-861c-436f-8948-871d19cf0c61.png)
![image](https://user-images.githubusercontent.com/100275369/194843871-9275742e-37d1-4228-baf1-9e8e325ca947.png)
![image](https://user-images.githubusercontent.com/100275369/194843892-e9f5f7a3-5395-4df8-a84a-a730e7004f06.png)

